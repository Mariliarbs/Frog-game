READ ME  - FROGGER GAME

Criação de jogo para o Nanodegree em Front-End Web Developer da Udacity.

Objetivo

Atravessar a grama e virar uma menina.

Controles

Usar as setas para mover o personagem.

Instalação

Fazer o download do arquivo zip.
Unzip 
Abrir o index.html em seu navegador de preferencia
JOGAR!


Tecnologias usadas

HTML5 canvas
CSS
JavaScript

Autora

Marilia de Rossi Barros